package rpc_layer;

public enum OperationEnums {
	operationSESSIONREAD, operationSESSIONWRITE, operationDELETE, operationGETMEMBERS	
}