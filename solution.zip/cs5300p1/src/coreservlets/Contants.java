package coreservlets;

 public class Contants {
	 static public final int k = 1;
}
